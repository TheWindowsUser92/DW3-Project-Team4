<?php
//Login info 
define('HOST','localhost');
define('USER','root');
define('PASS','');

//DB info 
