
<!-- THIS IS A TEST PAGE TO SEE INTERACTION -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login Form</title>
</head>
<body>
    <h2>User Login Form</h2>
    <form method="post" action="login.php">
        Username: <input type="text" name="username"><br><br>
        Password: <input type="password" name="password"><br><br>
        <button type="submit">Login</button>
        <button type="button" onclick="window.location.href='changingPasswordOfExistingUser.php'">Change Password</button>
    </form> 
</body>
</html>
