<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'kidsGames';

// Establishing Connection
try {
    $connection = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully<br>";
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

