<?php

$hostname = 'localhost';
$usename = 'root';
$password = '';
$datbase = 'kidsGames';

// Establishing Connection
try {
    $connection = new PDO("mysql:host=$hostname", $username, $password);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully<br>";
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Creating Database
try {
    $sqlCode = "CREATE DATABASE IF NOT EXISTS $database";
    $connection->exec($sqlCode);
    echo "Database created or already exists<br>";
} catch (PDOException $e) {
    die("Database creation failed: " . $e->getMessage());
}

// Selecting Database
try {
    $connection->exec("USE $database");
    echo "Database selected<br>";
} catch (PDOException $e) {
    die("Database selection failed: " . $e->getMessage());
}

// Create player Table
try {
    $sqlCode = "CREATE TABLE IF NOT EXISTS player( 
        fName VARCHAR(50) NOT NULL, 
        lName VARCHAR(50) NOT NULL, 
        userName VARCHAR(20) NOT NULL UNIQUE,
        registrationTime DATETIME NOT NULL,
        id VARCHAR(200) GENERATED ALWAYS AS (CONCAT(UPPER(LEFT(fName,2)),UPPER(LEFT(lName,2)),UPPER(LEFT(userName,3)),CAST(registrationTime AS SIGNED))) STORED,
        registrationOrder INT AUTO_INCREMENT PRIMARY KEY
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;";
    $connection->exec($sqlCode);
    echo "Player table created or already exists<br>";
} catch (PDOException $e) {
    die("Player table creation failed: " . $e->getMessage());
}

// Create authenticator Table
try {
    $sqlCode = "CREATE TABLE IF NOT EXISTS authenticator( 
        passCode VARCHAR(255) NOT NULL,
        registrationOrder INT, 
        FOREIGN KEY (registrationOrder) REFERENCES player(registrationOrder)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;";
    $connection->exec($sqlCode);
    echo "Authenticator table created or already exists<br>";
} catch (PDOException $e) {
    die("Authenticator table creation failed: " . $e->getMessage());
}


// Create score Table
try {
    $sqlCode = "CREATE TABLE IF NOT EXISTS score( 
        scoreTime DATETIME NOT NULL, 
        result ENUM('win', 'gameover', 'incomplete') NOT NULL,
        livesUsed INT NOT NULL,
        registrationOrder INT, 
        FOREIGN KEY (registrationOrder) REFERENCES player(registrationOrder)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;";
    $connection->exec($sqlCode);
    echo "Score table created or already exists<br>";
} catch (PDOException $e) {
    die("Score table creation failed: " . $e->getMessage());
}

// Create history View
try{
	$sqlCode = "CREATE OR REPLACE VIEW history AS
    SELECT s.scoreTime, p.id, p.fName, p.lName, s.result, s.livesUsed 
    FROM player p
    JOIN score s ON p.registrationOrder = s.registrationOrder;";
	echo "History view created or replaced<br>";
	$connection->exec($sqlCode);
}catch(PDOException $e){
	die("History view creation or replaced" . $e->getMessage());
}

// Insert Into player Table
try {
    $sqlCode = "INSERT INTO player (fName, lName, userName, registrationTime) VALUES 
                ('Patrick', 'Saint-Louis', 'sonic12345', NOW()), 
                ('Marie', 'Jourdain', 'asterix2023', NOW()), 
                ('Jonathan', 'David', 'pokemon527', NOW())";
    $connection->exec($sqlCode);
    echo "Data inserted into the player table successfully.<br>";
} catch (PDOException $error) {
    die("Data insertion into the player table failed <br>" . $error->getMessage());
}

// Insert Into authenticator Table
try {
    $sqlCode = "INSERT INTO authenticator (passCode, registrationOrder) VALUES 
                ('$2y$10$AMyb4cbGSWSvEcQxt91ZVu5r5OV7/3mMZl7tn8wnZrJ1ddidYfVYW', 1), 
                ('$2y$10$Lpd3JsgFW9.x2ft6Qo9h..xmtm82lmSuv/vaQKs9xPJ4rhKlMJAF.', 2), 
                ('$2y$10$FRAyAIK6.TYEEmbOHF4JfeiBCdWFHcqRTILM7nF/7CPjE3dNEWj3W', 3)";
    $connection->exec($sqlCode);
    echo "Data inserted into the authenticator table successfully.<br>";
} catch (PDOException $error) {
    die("Data insertion into the authenticator table failed <br>" . $error->getMessage());
}

// Insert Into score Table
try {
    $sqlCode = "INSERT INTO score (scoreTime, result, livesUsed, registrationOrder) VALUES 
                (NOW(), 'win', 4, 1), 
                (NOW(), 'gameover', 6, 2), 
                (NOW(), 'incomplete', 5, 3)";
    $connection->exec($sqlCode);
    echo "Data inserted into the score table successfully.<br>";
} catch (PDOException $error) {
    die("Data insertion into the score table failed <br>" . $error->getMessage());
}

unset($connection);

