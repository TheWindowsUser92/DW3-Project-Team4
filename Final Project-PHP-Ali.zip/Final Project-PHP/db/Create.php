<?php
include 'Database.php';

// Creating Database if not exists
try {
    $sqlCode = "CREATE DATABASE IF NOT EXISTS $database";
    $connection->exec($sqlCode);
    echo "Database created or already exists<br>";
} catch (PDOException $e) {
    die("Database creation failed: " . $e->getMessage());
}

// Selecting Database
try {
    $connection->exec("USE $database");
    echo "Database selected<br>";
} catch (PDOException $e) {
    die("Database selection failed: " . $e->getMessage());
}


// Create authenticator Table
try {
    $sqlCode = "CREATE TABLE IF NOT EXISTS authenticator( 
        passCode VARCHAR(255) NOT NULL,
        registrationOrder INT, 
        FOREIGN KEY (registrationOrder) REFERENCES player(registrationOrder)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;";
    $connection->exec($sqlCode);
    echo "Authenticator table created or already exists<br>";
} catch (PDOException $e) {
    die("Authenticator table creation failed: " . $e->getMessage());
}

// Create score Table
try {
    $sqlCode = "CREATE TABLE IF NOT EXISTS score( 
        scoreTime DATETIME NOT NULL, 
        result ENUM('win', 'gameover', 'incomplete') NOT NULL,
        livesUsed INT NOT NULL,
        registrationOrder INT, 
        FOREIGN KEY (registrationOrder) REFERENCES player(registrationOrder)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;";
    $connection->exec($sqlCode);
    echo "Score table created or already exists<br>";
} catch (PDOException $e) {
    die("Score table creation failed: " . $e->getMessage());
}

// Create history View
try {
    $sqlCode = "CREATE OR REPLACE VIEW history AS
    SELECT s.scoreTime, p.id, p.fName, p.lName, s.result, s.livesUsed 
    FROM player p
    JOIN score s ON p.registrationOrder = s.registrationOrder;";
    $connection->exec($sqlCode);
    echo "History view created or replaced<br>";
} catch (PDOException $e) {
    die("History view creation failed: " . $e->getMessage());
}

$connection = null;

